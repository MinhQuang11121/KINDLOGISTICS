"use client";

import { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { Search, X, Loader2, Clock, MessageSquare, User, ArrowLeft, Mic, Volume2, Hash, Tag, Monitor, Keyboard, ClipboardCopy, AppWindow } from "lucide-react";
import { useKeywordSearchStore, SearchMatch, UiEventResult } from "@/lib/hooks/use-keyword-search-store";
import { useSearchHighlight } from "@/lib/hooks/use-search-highlight";
import { useSearchFocus } from "./hooks/use-search-focus";
import { listen } from "@tauri-apps/api/event";
import { invoke } from "@tauri-apps/api/core";
import { useDebounce } from "@/lib/hooks/use-debounce";
import { format, isToday, isYesterday } from "date-fns";
import { cn } from "@/lib/utils";
import { commands } from "@/lib/utils/tauri";
import { showChatWithPrefill } from "@/lib/chat-utils";
import { ThumbnailHighlightOverlay } from "./thumbnail-highlight-overlay";

interface SpeakerResult {
  id: number;
  name: string;
  metadata: string;
}

interface AudioTranscription {
  timestamp: string;
  transcription: string;
  device_name: string;
  is_input: boolean;
  speaker_name: string;
  duration_secs: number;
}


interface TaggedFrame {
  frame_id: number;
  timestamp: string;
  tag_names: string[];
  app_name: string;
}

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToTimestamp: (timestamp: string, frameId?: number, searchTerms?: string[], searchResultsJson?: string, searchQuery?: string) => void;
  embedded?: boolean;
  /** When true, this is rendered in its own Tauri window (no backdrop, always open) */
  standalone?: boolean;
}

// stopwords to filter out from suggestions — keep this minimal so real
// content words survive. Only filter grammatical words and code tokens.
const STOP_WORDS = new Set([
  // grammar / function words
  "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
  "of", "with", "by", "from", "is", "it", "this", "that", "was", "are",
  "be", "has", "had", "have", "not", "no", "do", "does", "did", "will",
  "can", "could", "would", "should", "may", "might", "shall", "if", "so",
  "as", "he", "she", "we", "they", "you", "my", "your", "his", "her",
  "its", "our", "their", "me", "him", "us", "them", "am", "been", "being",
  "were", "what", "which", "who", "whom", "when", "where", "why", "how",
  "all", "each", "every", "both", "few", "more", "most", "other", "some",
  "such", "than", "too", "very", "just", "about", "above", "after", "again",
  "also", "any", "because", "before", "between", "here", "there", "then",
  "these", "those", "through", "under", "until", "while", "into", "over",
  "only", "own", "same", "still", "now",
  // code / web tokens
  "com", "www", "http", "https", "html", "css", "div", "span", "class",
  "true", "false", "null", "undefined", "var", "let", "const", "function",
  "return", "import", "export", "default", "type", "interface", "void",
  "png", "jpg", "svg", "gif", "src", "img", "alt",
  "width", "height", "style", "font", "size", "color",
]);

function isGarbageWord(word: string): boolean {
  if (word.length < 3 || word.length > 25) return true;
  // too many consonants in a row = OCR garbage
  if (/[bcdfghjklmnpqrstvwxyz]{5,}/i.test(word)) return true;
  // pure numbers
  if (/^\d+$/.test(word)) return true;
  // numbers mixed with letters (like "h3" "x11" etc)
  if (/\d/.test(word) && /[a-z]/i.test(word) && word.length < 6) return true;
  // repeated chars
  if (/(.)\1{3,}/.test(word)) return true;
  // common file extensions / code tokens
  if (/^\.(js|ts|py|rs|md|json|yaml|toml|lock|env|cfg)$/i.test(word)) return true;
  return false;
}

// words that are proper nouns (Capitalized in original text) are more interesting
function extractInterestingWords(text: string): Map<string, { count: number; original: string }> {
  const words = new Map<string, { count: number; original: string }>();
  // split on whitespace/punctuation, match words 3-25 chars (letters, including unicode)
  const tokens = text.match(/[\p{L}]{3,25}/gu) || [];
  for (const token of tokens) {
    const lower = token.toLowerCase();
    if (STOP_WORDS.has(lower)) continue;
    if (isGarbageWord(lower)) continue;
    const existing = words.get(lower);
    if (existing) {
      existing.count++;
      // prefer the Capitalized version
      if (token[0] === token[0].toUpperCase() && token.slice(1) === token.slice(1).toLowerCase()) {
        existing.original = token;
      }
    } else {
      words.set(lower, { count: 1, original: token });
    }
  }
  return words;
}

function useSuggestions(isOpen: boolean) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    let cancelled = false;
    setIsLoading(true);

    (async () => {
      try {
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        // Match the keyword search exclusion window (1 minute) so suggestions
        // only contain words from data that's already FTS-indexed.
        const endTime = new Date(now.getTime() - 60_000);

        const params = new URLSearchParams({
          content_type: "ocr",
          limit: "100",
          offset: "0",
          start_time: oneDayAgo.toISOString(),
          end_time: endTime.toISOString(),
        });

        const resp = await fetch(`http://localhost:3030/search?${params}`, {
          signal: AbortSignal.timeout(5000),
        });
        if (cancelled) return;
        if (!resp.ok) {
          if (!cancelled) setIsLoading(false);
          return;
        }

        const data = await resp.json();
        const items = data?.data || [];

        // collect app names (always useful as suggestions)
        const appNameCounts = new Map<string, { count: number; original: string }>();
        const allWords = new Map<string, { count: number; original: string }>();

        for (const item of items) {
          const content = item?.content || {};
          const appName = (content.app_name || "").trim();
          if (appName) {
            const lower = appName.toLowerCase();
            const existing = appNameCounts.get(lower);
            if (existing) {
              existing.count++;
            } else {
              appNameCounts.set(lower, { count: 1, original: appName });
            }
          }

          const text = content.text || "";
          const extracted = extractInterestingWords(text);
          for (const [lower, info] of extracted) {
            const existing = allWords.get(lower);
            if (existing) {
              existing.count += info.count;
              if (info.original[0] === info.original[0].toUpperCase()) {
                existing.original = info.original;
              }
            } else {
              allWords.set(lower, { ...info });
            }
          }
        }

        if (cancelled) return;

        const appNameSet = new Set(appNameCounts.keys());

        // filter keywords: exclude app names, not too frequent (UI chrome)
        const maxCount = Math.max(items.length * 0.6, 5);
        const candidates = [...allWords.entries()]
          .filter(([lower]) => !appNameSet.has(lower))
          .filter(([, info]) => info.count >= 1 && info.count < maxCount)
          .sort((a, b) => {
            const aProper = a[1].original[0] === a[1].original[0].toUpperCase() ? 1 : 0;
            const bProper = b[1].original[0] === b[1].original[0].toUpperCase() ? 1 : 0;
            if (bProper !== aProper) return bProper - aProper;
            return b[1].count - a[1].count;
          });

        // take top 20 then randomly pick 8 for variety
        const topPool = candidates.slice(0, 20);
        const shuffled = topPool.sort(() => Math.random() - 0.5);
        let picked = shuffled.slice(0, 8).map(([, info]) => info.original);

        // fallback: always fill remaining slots with top app names
        // (app names are the most reliable suggestions — always available)
        if (picked.length < 8 && appNameCounts.size > 0) {
          const topApps = [...appNameCounts.entries()]
            .sort((a, b) => b[1].count - a[1].count)
            .slice(0, 8 - picked.length)
            .map(([, info]) => info.original);
          picked = [...picked, ...topApps];
        }

        if (!cancelled) {
          setSuggestions(picked);
          setIsLoading(false);
        }
      } catch {
        if (!cancelled) setIsLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isOpen]);

  return { suggestions, isLoading };
}

// Frame thumbnail component with loading state and retry logic
const FrameThumbnail = ({ frameId, alt }: { frameId: number; alt: string }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [src, setSrc] = useState(`http://localhost:3030/frames/${frameId}`);
  const retryCount = useRef(0);

  useEffect(() => {
    setSrc(`http://localhost:3030/frames/${frameId}`);
    setIsLoading(true);
    setHasError(false);
    retryCount.current = 0;
  }, [frameId]);

  return (
    <div className="aspect-video bg-muted relative overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}
      {hasError ? (
        <div className="absolute inset-0 flex items-center justify-center bg-muted">
          <span className="text-xs text-muted-foreground">unavailable</span>
        </div>
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src}
          alt={alt}
          className={cn(
            "w-full h-full object-cover transition-opacity select-none",
            isLoading ? "opacity-0" : "opacity-100"
          )}
          loading="lazy"
          draggable={false}
          data-lm-disable="true"
          onLoad={() => setIsLoading(false)}
          onError={() => {
            if (retryCount.current < 3) {
              retryCount.current += 1;
              setTimeout(() => {
                setSrc(`http://localhost:3030/frames/${frameId}?retry=${retryCount.current}`);
              }, 1000 * retryCount.current);
            } else {
              setIsLoading(false);
              setHasError(true);
            }
          }}
        />
      )}
    </div>
  );
};

// Format relative time
function formatRelativeTime(timestamp: string): string {
  const date = new Date(timestamp);
  const time = format(date, "h:mm a");
  if (isToday(date)) return time;
  if (isYesterday(date)) return `yesterday ${time}`;
  return format(date, "MMM d") + " " + time;
}

/** Compact keyboard/clipboard result item — shows 1 line by default, expands on click */
function UiEventItem({ evt, onNavigate }: { evt: UiEventResult; onNavigate: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const EvtIcon = evt.event_type === "clipboard" ? ClipboardCopy
    : evt.event_type === "app_switch" ? AppWindow
    : Keyboard;

  return (
    <div
      className="cursor-pointer border border-border rounded p-2 hover:border-foreground/50 transition-colors"
    >
      <div className="flex items-start justify-between gap-3">
        <div
          className="flex items-start gap-2 min-w-0 flex-1"
          onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
        >
          <EvtIcon className="w-3.5 h-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
          <div className="min-w-0">
            <p className={cn("text-xs text-foreground", !expanded && "line-clamp-1")}>
              {evt.text_content}
            </p>
            {(evt.app_name || evt.window_title) && (
              <p className="text-[11px] text-muted-foreground mt-0.5 truncate">
                {[evt.app_name, evt.window_title].filter(Boolean).join(" — ")}
              </p>
            )}
          </div>
        </div>
        <span
          className="text-[11px] text-muted-foreground font-mono flex-shrink-0 hover:text-foreground hover:underline"
          onClick={onNavigate}
          title="Go to timestamp"
        >
          {formatRelativeTime(evt.timestamp)}
        </span>
      </div>
    </div>
  );
}

export function SearchModal({ isOpen, onClose, onNavigateToTimestamp, embedded = false, standalone = false }: SearchModalProps) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const { inputRef, inputElRef, focusInput } = useSearchFocus(isOpen);
  const gridRef = useRef<HTMLDivElement>(null);

  // Programmatically scroll via native-scroll events (macOS).
  // WKWebView in settings WebviewWindow doesn't dispatch JS wheel events,
  // so CSS overflow can't scroll from trackpad. The Rust side swizzles
  // WKWebView.scrollWheel: and emits "native-scroll" Tauri events instead.
  // We find the scrollable element under the cursor and apply the delta.
  useEffect(() => {
    if (!isOpen || !embedded) return;

    // Track cursor position for hit-testing
    let mouseX = 0, mouseY = 0;
    const onMove = (e: MouseEvent) => { mouseX = e.clientX; mouseY = e.clientY; };
    document.addEventListener("mousemove", onMove);

    const unlisten = listen<{ deltaX: number; deltaY: number; ctrlKey: boolean; metaKey: boolean }>(
      "native-scroll",
      (event) => {
        const { deltaX, deltaY } = event.payload;
        // Find element under cursor and walk up to nearest scrollable container
        const target = document.elementFromPoint(mouseX, mouseY);
        if (!target) return;

        let el: HTMLElement | null = target as HTMLElement;
        let scrolledY = false;
        let scrolledX = false;

        while (el) {
          const style = window.getComputedStyle(el);
          const overflowY = style.overflowY;
          const overflowX = style.overflowX;

          // Vertical scroll
          if (!scrolledY && Math.abs(deltaY) > 0 && (overflowY === "auto" || overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
            el.scrollTop -= deltaY;
            scrolledY = true;
          }

          // Horizontal scroll (trackpad horizontal swipe or shift+scroll)
          if (!scrolledX && Math.abs(deltaX) > 0 && (overflowX === "auto" || overflowX === "scroll") && el.scrollWidth > el.clientWidth) {
            el.scrollLeft -= deltaX;
            scrolledX = true;
          }

          if (scrolledY && scrolledX) break;
          el = el.parentElement;
        }

        // Fallback: vertical scroll the grid if nothing else caught it
        if (!scrolledY && Math.abs(deltaY) > 0 && gridRef.current) {
          gridRef.current.scrollTop -= deltaY;
        }
      },
    );
    return () => {
      document.removeEventListener("mousemove", onMove);
      unlisten.then((f) => f());
    };
  }, [isOpen, embedded]);

  // Bump to force search effect re-run (fixes stale debouncedQuery after modal reopen)
  const [searchEpoch, setSearchEpoch] = useState(0);

  // Speaker search state
  const [speakerResults, setSpeakerResults] = useState<SpeakerResult[]>([]);
  const [isSearchingSpeakers, setIsSearchingSpeakers] = useState(false);
  // Drill-down: selected speaker to show their transcriptions
  const [selectedSpeaker, setSelectedSpeaker] = useState<SpeakerResult | null>(null);
  const [speakerTranscriptions, setSpeakerTranscriptions] = useState<AudioTranscription[]>([]);
  const [isLoadingTranscriptions, setIsLoadingTranscriptions] = useState(false);
  const [selectedTranscriptionIndex, setSelectedTranscriptionIndex] = useState(0);
  const [transcriptionFrames, setTranscriptionFrames] = useState<Map<string, { frame_id: number; app_name: string }>>(new Map());

  // Tag search state
  const [tagResults, setTagResults] = useState<TaggedFrame[]>([]);
  const [allTags, setAllTags] = useState<string[]>([]); // distinct tags for autocomplete
  const [isSearchingTags, setIsSearchingTags] = useState(false);
  const isTagSearch = query.startsWith("#");
  const isPeopleSearch = query.startsWith("@");

  // Content type filter
  type ContentFilter = "all" | "screen" | "input";
  const [contentFilter, setContentFilter] = useState<ContentFilter>("all");

  // App filter (for screen results and speaker drill-down)
  const [appFilter, setAppFilter] = useState<string | null>(null);
  const [speakerAppFilter, setSpeakerAppFilter] = useState<string | null>(null);
  const [domainFilter, setDomainFilter] = useState<string | null>(null);
  // Time filter — stores the date string (YYYY-MM-DD) from a time range chip
  const [timeFilter, setTimeFilter] = useState<string | null>(null);
  const [speakerTimeFilter, setSpeakerTimeFilter] = useState<string | null>(null);

  // Pagination
  const [ocrOffset, setOcrOffset] = useState(0);
  const [hasMoreOcr, setHasMoreOcr] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [transcriptionOffset, setTranscriptionOffset] = useState(0);
  const [hasMoreTranscriptions, setHasMoreTranscriptions] = useState(true);
  const [isLoadingMoreTranscriptions, setIsLoadingMoreTranscriptions] = useState(false);

  const OCR_PAGE_SIZE = 24;
  const TRANSCRIPTION_PAGE_SIZE = 30;

  const debouncedQuery = useDebounce(query, 400);
  const { suggestions, isLoading: suggestionsLoading } = useSuggestions(isOpen);

  const {
    searchResults,
    searchGroups,
    uiEventResults,
    isSearchingUiEvents,
    isSearching,
    searchKeywords,
    resetSearch,
    setCurrentResultIndex,
  } = useKeywordSearchStore();

  // --- Facet state (loaded async, independent of paginated results) ---
  const [facetApps, setFacetApps] = useState<[string, number][]>([]);
  const [facetDomains, setFacetDomains] = useState<[string, number][]>([]);
  const [facetTimeRanges, setFacetTimeRanges] = useState<{ label: string; dateKey: string; timestamp: string; count: number }[]>([]);
  const [facetsLoading, setFacetsLoading] = useState(false);

  // Build time range labels from raw rows
  const buildTimeRanges = useCallback((rows: { dateKey: string; timestamp: string; count: number }[]) => {
    // Re-bucket by local date since SQL DATE() operates on UTC strings.
    // Multiple UTC dates can map to the same local date, so merge counts.
    const buckets = new Map<string, { label: string; dateKey: string; timestamp: string; count: number }>();
    for (const r of rows) {
      const d = new Date(r.timestamp);
      const localDateKey = format(d, "yyyy-MM-dd");
      const existing = buckets.get(localDateKey);
      if (existing) {
        existing.count += r.count;
      } else {
        let label: string;
        if (isToday(d)) {
          label = format(d, "h a");
        } else if (isYesterday(d)) {
          label = "yesterday " + format(d, "h a");
        } else {
          label = format(d, "MMM d");
        }
        buckets.set(localDateKey, { label, dateKey: localDateKey, timestamp: r.timestamp, count: r.count });
      }
    }
    return [...buckets.values()]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
  }, []);

  // Async facet loading — fires a lightweight SQL aggregation query
  useEffect(() => {
    const q = debouncedQuery.trim();
    if (!q || q.length < 3 || q.startsWith("#") || q.startsWith("@")) {
      setFacetApps([]);
      setFacetDomains([]);
      setFacetTimeRanges([]);
      setFacetsLoading(false);
      return;
    }

    let cancelled = false;
    setFacetsLoading(true);
    let pending = 3;
    const onFacetDone = () => { pending--; if (pending === 0 && !cancelled) setFacetsLoading(false); };
    const escaped = q.replace(/"/g, '""');
    const ftsQuery = q.split(/\s+/).map(w => `"${w.replace(/"/g, '""')}"`).join(" OR ");

    // Fire all three facet queries in parallel
    const fetchFacet = async (sql: string) => {
      const resp = await fetch("http://localhost:3030/raw_sql", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: sql }),
        signal: AbortSignal.timeout(5000),
      });
      return resp.ok ? resp.json() : [];
    };

    // App facet (single frames_fts query)
    fetchFacet(
      `SELECT app_name as app, COUNT(*) as cnt
       FROM frames_fts
       WHERE frames_fts MATCH '${escaped}'
       AND app_name != ''
       GROUP BY app_name ORDER BY cnt DESC LIMIT 15`
    ).then((rows: { app: string; cnt: number }[]) => {
      if (!cancelled) setFacetApps(rows.map(r => [r.app, r.cnt]));
    }).catch(() => {}).finally(onFacetDone);

    // Domain facet (frames_fts joined with frames for browser_url)
    // Note: FTS5 tables cannot be aliased, must use full table name in MATCH
    fetchFacet(
      `SELECT f.browser_url as url, COUNT(*) as cnt
       FROM frames_fts
       JOIN frames f ON f.id = frames_fts.id
       WHERE frames_fts MATCH '${escaped}'
       AND f.browser_url IS NOT NULL AND f.browser_url != ''
       GROUP BY f.browser_url ORDER BY cnt DESC LIMIT 200`
    ).then((rows: { url: string; cnt: number }[]) => {
      if (cancelled) return;
      // Aggregate by domain
      const domainMap = new Map<string, number>();
      for (const r of rows) {
        try {
          const domain = new URL(r.url).hostname.replace(/^www\./, "");
          if (domain) domainMap.set(domain, (domainMap.get(domain) || 0) + r.cnt);
        } catch { /* skip */ }
      }
      setFacetDomains([...domainMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8));
    }).catch(() => {}).finally(onFacetDone);

    // Time facet — bucket by date (frames_fts)
    fetchFacet(
      `SELECT DATE(f.timestamp) as d, MIN(f.timestamp) as ts, COUNT(*) as cnt
       FROM frames_fts
       JOIN frames f ON f.id = frames_fts.id
       WHERE frames_fts MATCH '${escaped}'
       GROUP BY DATE(f.timestamp)
       ORDER BY d DESC LIMIT 30`
    ).then((rows: { d: string; ts: string; cnt: number }[]) => {
      if (cancelled) return;
      setFacetTimeRanges(buildTimeRanges(rows.map(r => ({ dateKey: r.d, timestamp: r.ts, count: r.cnt }))));
    }).catch(() => {}).finally(onFacetDone);

    return () => { cancelled = true; setFacetsLoading(false); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedQuery, buildTimeRanges, searchEpoch]);

  // Speaker time ranges (from loaded transcriptions — these are small enough)
  const speakerTimeRanges = useMemo(() => {
    if (speakerTranscriptions.length === 0) return [];
    const buckets = new Map<string, { label: string; dateKey: string; timestamp: string; count: number }>();
    for (const t of speakerTranscriptions) {
      const d = new Date(t.timestamp);
      if (isNaN(d.getTime())) continue;
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      if (!buckets.has(key)) {
        const dateKey = format(d, "yyyy-MM-dd");
        let label: string;
        if (isToday(d)) label = format(d, "h a");
        else if (isYesterday(d)) label = "yesterday " + format(d, "h a");
        else label = format(d, "MMM d");
        buckets.set(key, { label, dateKey, timestamp: t.timestamp, count: 1 });
      } else {
        buckets.get(key)!.count++;
      }
    }
    return [...buckets.values()]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
  }, [speakerTranscriptions]);

  const domainCounts = facetDomains;
  const timeRanges = facetTimeRanges;

  // Compute app distribution from speaker transcription frames
  const speakerAppCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const [, info] of transcriptionFrames) {
      if (info.app_name) {
        counts.set(info.app_name, (counts.get(info.app_name) || 0) + 1);
      }
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]);
  }, [transcriptionFrames]);

  // Filter speaker transcriptions by app and time
  const filteredSpeakerTranscriptions = useMemo(() => {
    let items = speakerTranscriptions;
    if (speakerAppFilter) items = items.filter(t => {
      const info = transcriptionFrames.get(t.timestamp);
      return info?.app_name === speakerAppFilter;
    });
    if (speakerTimeFilter) items = items.filter(t => t.timestamp.startsWith(speakerTimeFilter));
    return items;
  }, [speakerTranscriptions, speakerAppFilter, speakerTimeFilter, transcriptionFrames]);

  const matchesTimeFilter = useCallback((timestamp: string) => {
    if (!timeFilter) return true;
    // Compare in local time — timeFilter is a local date like "2026-02-28"
    const d = new Date(timestamp);
    const localDate = format(d, "yyyy-MM-dd");
    return localDate === timeFilter;
  }, [timeFilter]);

  // Derive app chips from time-filtered results so they stay consistent
  // when a date chip is active. Uses actual search result app_names to
  // guarantee the client-side filter (r.app_name === appFilter) matches.
  // Use facet data (aggregated over ALL matches) when available,
  // fall back to client-side counts from loaded results when facets haven't loaded yet
  const appCounts = useMemo(() => {
    if (facetApps.length > 0 && !timeFilter) return facetApps;
    const source = timeFilter
      ? searchResults.filter(r => matchesTimeFilter(r.timestamp))
      : searchResults;
    const counts = new Map<string, number>();
    for (const r of source) {
      counts.set(r.app_name, (counts.get(r.app_name) || 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]);
  }, [facetApps, searchResults, timeFilter, matchesTimeFilter]);

  const filteredResults = useMemo(() => {
    let results = searchResults;
    if (appFilter) results = results.filter(r => r.app_name === appFilter);
    if (domainFilter) results = results.filter(r => {
      try { return new URL(r.url).hostname.replace(/^www\./, "") === domainFilter; } catch { return false; }
    });
    if (timeFilter) results = results.filter(r => matchesTimeFilter(r.timestamp));
    return results;
  }, [searchResults, appFilter, domainFilter, timeFilter, matchesTimeFilter]);

  // Keep a ref so keyboard handler reads current value without re-mounting the effect
  const filteredResultsRef = useRef(filteredResults);
  filteredResultsRef.current = filteredResults;
  const filteredSpeakerTranscriptionsRef = useRef(filteredSpeakerTranscriptions);
  filteredSpeakerTranscriptionsRef.current = filteredSpeakerTranscriptions;

  const filteredGroups = useMemo(() => {
    let groups = searchGroups;
    if (appFilter) groups = groups.filter(g => g.representative.app_name === appFilter);
    if (domainFilter) groups = groups.filter(g => {
      try { return new URL(g.representative.url).hostname.replace(/^www\./, "") === domainFilter; } catch { return false; }
    });
    if (timeFilter) groups = groups.filter(g => matchesTimeFilter(g.representative.timestamp));
    return groups;
  }, [searchGroups, appFilter, domainFilter]);

  // Tokenize query for thumbnail highlights (split on spaces, filter empty)
  const queryTokens = useMemo(() => {
    if (!debouncedQuery || isTagSearch || isPeopleSearch) return [];
    return debouncedQuery.split(/\s+/).filter((t) => t.length > 0);
  }, [debouncedQuery, isTagSearch, isPeopleSearch]);

  const { setHighlight, clear: clearHighlight } = useSearchHighlight();

  // Reset state when modal opens (focus is handled by useSearchFocus)
  useEffect(() => {
    if (isOpen) {
      setSelectedIndex(0);
      setQuery("");
      resetSearch();
      setSearchEpoch(e => e + 1);
      clearHighlight();
      setAppFilter(null);
      setDomainFilter(null);
      setTimeFilter(null);
      setContentFilter("all");
      setSpeakerResults([]);
      setTagResults([]);
      setAllTags([]);
      setSelectedSpeaker(null);
      setSpeakerTranscriptions([]);
      setSelectedTranscriptionIndex(0);
      setOcrOffset(0);
      setHasMoreOcr(true);
      setTranscriptionOffset(0);
      setHasMoreTranscriptions(true);
    }
  }, [isOpen, resetSearch]);

  // Perform search when query changes
  useEffect(() => {
    const q = debouncedQuery.trim();
    if (!q || q.startsWith("#") || q.startsWith("@")) {
      resetSearch();
      setSpeakerResults([]);
      setTagResults([]);
      setAppFilter(null);
      setDomainFilter(null);
      setTimeFilter(null);
      return;
    }

    // Require at least 3 chars to avoid wasteful FTS queries while typing
    if (q.length < 3) return;

    setAppFilter(null);
    setDomainFilter(null);
    setTimeFilter(null);
    setContentFilter("all");
    setTagResults([]);
    setOcrOffset(0);
    setHasMoreOcr(true);
    searchKeywords(debouncedQuery, {
      limit: OCR_PAGE_SIZE,
      offset: 0,
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedQuery, searchKeywords, resetSearch, searchEpoch]);

  // Search tags when query starts with #
  useEffect(() => {
    if (!debouncedQuery.startsWith("#")) {
      setTagResults([]);
      setAllTags([]);
      return;
    }

    const tagQuery = debouncedQuery.slice(1).trim().toLowerCase(); // strip #
    let cancelled = false;

    (async () => {
      setIsSearchingTags(true);
      try {
        // Fetch all distinct tags with counts from the tags + vision_tags tables
        const tagsResp = await fetch("http://localhost:3030/raw_sql", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: "SELECT t.name, COUNT(vt.vision_id) as count FROM tags t JOIN vision_tags vt ON t.id = vt.tag_id GROUP BY t.id, t.name ORDER BY count DESC",
          }),
          signal: AbortSignal.timeout(5000),
        });

        if (cancelled) return;
        const allDbTags: { name: string; count: number }[] = tagsResp.ok
          ? await tagsResp.json()
          : [];

        // Set autocomplete pills (filtered if user typed something after #)
        const tagNames = allDbTags.map(t => t.name);
        setAllTags(
          tagQuery.length > 0
            ? tagNames.filter(t => t.toLowerCase().includes(tagQuery))
            : tagNames
        );

        // Find tags that match the query
        const matched = tagQuery.length > 0
          ? allDbTags.filter(t => t.name.toLowerCase().includes(tagQuery))
          : allDbTags;

        if (matched.length > 0 && !cancelled) {
          // Fetch frames tagged with matching tags
          const inList = matched.map(t => `'${t.name.replace(/'/g, "''")}'`).join(",");
          const framesResp = await fetch("http://localhost:3030/raw_sql", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              query: `SELECT f.id as frame_id, f.timestamp, f.app_name, GROUP_CONCAT(DISTINCT t.name) as tag_names FROM vision_tags vt JOIN frames f ON vt.vision_id = f.id JOIN tags t ON vt.tag_id = t.id WHERE t.name IN (${inList}) GROUP BY f.id ORDER BY f.timestamp DESC LIMIT 50`,
            }),
            signal: AbortSignal.timeout(5000),
          });

          if (cancelled) return;
          if (framesResp.ok) {
            const rows: { frame_id: number; timestamp: string; tag_names: string; app_name: string }[] = await framesResp.json();
            setTagResults(rows.map(r => ({
              frame_id: r.frame_id,
              timestamp: r.timestamp,
              tag_names: r.tag_names.split(","),
              app_name: r.app_name || "",
            })));
          }
        } else {
          setTagResults([]);
        }
      } catch {
        // ignore
      } finally {
        if (!cancelled) setIsSearchingTags(false);
      }
    })();

    return () => { cancelled = true; };
  }, [debouncedQuery]);

  // Search speakers — triggered by @query or normal text query (>= 2 chars)
  useEffect(() => {
    if (selectedSpeaker) {
      setSpeakerResults([]);
      return;
    }

    const isAtQuery = debouncedQuery.startsWith("@");
    const searchTerm = isAtQuery ? debouncedQuery.slice(1).trim() : debouncedQuery.trim();

    // For normal queries, require >= 2 chars; for @, show all speakers immediately
    if (!isAtQuery && (searchTerm.length < 2 || debouncedQuery.startsWith("#"))) {
      setSpeakerResults([]);
      return;
    }

    let cancelled = false;
    const controller = new AbortController();

    (async () => {
      setIsSearchingSpeakers(true);
      try {
        // For @ with no text, fetch all speakers; otherwise search by name
        const url = searchTerm.length > 0
          ? `http://localhost:3030/speakers/search?name=${encodeURIComponent(searchTerm)}`
          : `http://localhost:3030/speakers/search?name=`;
        const resp = await fetch(url, {
          signal: AbortSignal.any([controller.signal, AbortSignal.timeout(3000)]),
        });
        if (resp.ok && !cancelled) {
          const speakers: SpeakerResult[] = await resp.json();
          setSpeakerResults(speakers.filter(s => s.name).slice(0, isAtQuery ? 20 : 5));
        }
      } catch {
        // ignore
      } finally {
        if (!cancelled) setIsSearchingSpeakers(false);
      }
    })();

    return () => { cancelled = true; controller.abort(); };
  }, [debouncedQuery, selectedSpeaker]);

  // Load transcriptions when a speaker is selected
  useEffect(() => {
    if (!selectedSpeaker) {
      setSpeakerTranscriptions([]);
      setTranscriptionFrames(new Map());
      setTranscriptionOffset(0);
      setHasMoreTranscriptions(true);
      return;
    }

    let cancelled = false;
    const controller = new AbortController();

    (async () => {
      setIsLoadingTranscriptions(true);
      try {
        const params = new URLSearchParams({
          content_type: "audio",
          speaker_name: selectedSpeaker.name,
          limit: "30",
          offset: "0",
        });
        const resp = await fetch(
          `http://localhost:3030/search?${params}`,
          { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(5000)]) }
        );
        if (resp.ok && !cancelled) {
          const data = await resp.json();
          const items: AudioTranscription[] = (data?.data || []).map((item: any) => ({
            timestamp: item.content?.timestamp || "",
            transcription: item.content?.transcription || "",
            device_name: item.content?.device_name || "",
            is_input: item.content?.is_input ?? true,
            speaker_name: item.content?.speaker_name || selectedSpeaker.name,
            duration_secs: item.content?.duration_secs || 0,
          }));
          if (items.length < TRANSCRIPTION_PAGE_SIZE) setHasMoreTranscriptions(false);
          setSpeakerTranscriptions(items);

          // Fetch nearest frame for each transcription timestamp (in parallel batches)
          const uniqueTimestamps = [...new Set(items.map(i => i.timestamp).filter(Boolean))];
          if (uniqueTimestamps.length > 0 && !cancelled) {
            try {
              const map = new Map<string, { frame_id: number; app_name: string }>();
              // Batch fetch: find closest frame within ±30s for each timestamp
              const promises = uniqueTimestamps.map(async (ts) => {
                const d = new Date(ts);
                const lo = new Date(d.getTime() - 30_000).toISOString();
                const hi = new Date(d.getTime() + 30_000).toISOString();
                const escaped = ts.replace(/'/g, "''");
                const resp = await fetch("http://localhost:3030/raw_sql", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    query: `SELECT id as frame_id, app_name FROM frames WHERE timestamp >= '${lo}' AND timestamp <= '${hi}' ORDER BY ABS(julianday(timestamp) - julianday('${escaped}')) LIMIT 1`,
                  }),
                  signal: AbortSignal.timeout(3000),
                });
                if (resp.ok) {
                  const rows: { frame_id: number; app_name: string }[] = await resp.json();
                  if (rows.length > 0) map.set(ts, { frame_id: rows[0].frame_id, app_name: rows[0].app_name || "" });
                }
              });
              await Promise.all(promises);
              if (!cancelled) setTranscriptionFrames(map);
            } catch {
              // frames are optional, ignore errors
            }
          }
        }
      } catch {
        // ignore
      } finally {
        if (!cancelled) setIsLoadingTranscriptions(false);
      }
    })();

    return () => { cancelled = true; controller.abort(); };
  }, [selectedSpeaker]);

  // Send to AI handler
  const handleSendToAI = useCallback(async () => {
    const result = filteredResults[selectedIndex];
    if (!result) return;

    const context = `Context from search result:\n${result.app_name} - ${result.window_name}\nTime: ${format(new Date(result.timestamp), "PPpp")}\n\nText:\n${result.text || ""}`;

    // Close search modal first
    onClose();

    // Show chat window and deliver prefill (handles fresh webview creation)
    await showChatWithPrefill({ context, frameId: result.frame_id });
  }, [filteredResults, selectedIndex, onClose]);

  // Handle going back from speaker drill-down
  const handleBackFromSpeaker = useCallback(() => {
    setSelectedSpeaker(null);
    setSpeakerTranscriptions([]);
    setSpeakerAppFilter(null);
    setSpeakerTimeFilter(null);
    setSelectedTranscriptionIndex(0);
    setTranscriptionOffset(0);
    setHasMoreTranscriptions(true);
    requestAnimationFrame(() => focusInput());
  }, [focusInput]);

  // Load more OCR results
  const loadMoreOcr = useCallback(() => {
    if (isLoadingMore || !hasMoreOcr || !debouncedQuery.trim()) return;
    setIsLoadingMore(true);
    const newOffset = ocrOffset + OCR_PAGE_SIZE;
    setOcrOffset(newOffset);
    const opts: { limit: number; offset: number; start_time?: Date; end_time?: Date } = {
      limit: OCR_PAGE_SIZE,
      offset: newOffset,
    };
    if (timeFilter) {
      opts.start_time = new Date(timeFilter + "T00:00:00");
      opts.end_time = new Date(timeFilter + "T23:59:59.999");
    }
    searchKeywords(debouncedQuery, opts).finally(() => setIsLoadingMore(false));
  }, [isLoadingMore, hasMoreOcr, debouncedQuery, ocrOffset, searchKeywords, timeFilter]);

  // Track if we got fewer results than page size (= no more pages).
  // The server may filter results after fetching (e.g. app_name filter),
  // so we only stop when we get zero new results — not just fewer than PAGE_SIZE.
  const prevResultsLengthRef = useRef(0);
  useEffect(() => {
    const prevLen = prevResultsLengthRef.current;
    const curLen = searchResults.length;
    prevResultsLengthRef.current = curLen;
    // After a load-more, if no new results were added, we've exhausted all pages
    if (ocrOffset > 0 && curLen === prevLen && !isSearching) {
      setHasMoreOcr(false);
    }
  }, [searchResults.length, ocrOffset, isSearching]);

  // Load more speaker transcriptions
  const loadMoreTranscriptions = useCallback(async () => {
    if (isLoadingMoreTranscriptions || !hasMoreTranscriptions || !selectedSpeaker) return;
    setIsLoadingMoreTranscriptions(true);
    const newOffset = transcriptionOffset + TRANSCRIPTION_PAGE_SIZE;
    setTranscriptionOffset(newOffset);

    try {
      const params = new URLSearchParams({
        content_type: "audio",
        speaker_name: selectedSpeaker.name,
        limit: TRANSCRIPTION_PAGE_SIZE.toString(),
        offset: newOffset.toString(),
      });
      const resp = await fetch(
        `http://localhost:3030/search?${params}`,
        { signal: AbortSignal.timeout(5000) }
      );
      if (resp.ok) {
        const data = await resp.json();
        const items = (data?.data || []).map((item: any) => ({
          timestamp: item.content?.timestamp || "",
          transcription: item.content?.transcription || "",
          device_name: item.content?.device_name || "",
          is_input: item.content?.is_input ?? true,
          speaker_name: item.content?.speaker_name || selectedSpeaker.name,
          duration_secs: item.content?.duration_secs || 0,
        }));
        if (items.length < TRANSCRIPTION_PAGE_SIZE) setHasMoreTranscriptions(false);
        setSpeakerTranscriptions(prev => [...prev, ...items]);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingMoreTranscriptions(false);
    }
  }, [isLoadingMoreTranscriptions, hasMoreTranscriptions, selectedSpeaker, transcriptionOffset]);

  // Infinite scroll handler
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const target = e.currentTarget;
    const nearBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 200;

    if (nearBottom) {
      if (selectedSpeaker) {
        loadMoreTranscriptions();
      } else {
        loadMoreOcr();
      }
    }
  }, [selectedSpeaker, loadMoreOcr, loadMoreTranscriptions]);

  const handleSelectResult = useCallback((result: SearchMatch) => {
    if (queryTokens.length > 0) {
      setHighlight(queryTokens, result.frame_id);
    }
    // Track which result was selected so timeline arrow keys can cycle from here
    const idx = searchResults.findIndex((r) => r.frame_id === result.frame_id);
    if (idx >= 0) setCurrentResultIndex(idx);
    const resultsJson = JSON.stringify(searchResults);
    onNavigateToTimestamp(result.timestamp, result.frame_id, queryTokens, resultsJson, query);
    onClose();
  }, [onNavigateToTimestamp, onClose, queryTokens, setHighlight, searchResults, query, setCurrentResultIndex]);

  // Keyboard navigation — uses refs for data arrays to avoid re-mounting when results change
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const inputFocused = document.activeElement === inputElRef.current;

      // Speaker drill-down mode
      if (selectedSpeaker) {
        const transcriptions = filteredSpeakerTranscriptionsRef.current;
        switch (e.key) {
          case "Escape":
            e.preventDefault();
            handleBackFromSpeaker();
            break;
          case "ArrowDown":
            e.preventDefault();
            setSelectedTranscriptionIndex(i => Math.min(i + 1, transcriptions.length - 1));
            break;
          case "ArrowUp":
            e.preventDefault();
            setSelectedTranscriptionIndex(i => Math.max(i - 1, 0));
            break;
          case "Enter":
            e.preventDefault();
            setSelectedTranscriptionIndex(i => {
              if (transcriptions[i]?.timestamp) {
                onNavigateToTimestamp(transcriptions[i].timestamp);
                onClose();
              }
              return i;
            });
            break;
        }
        return;
      }

      // When input is focused, let left/right arrows move the cursor
      if (inputFocused && (e.key === "ArrowLeft" || e.key === "ArrowRight")) {
        return;
      }

      const cols = 3;
      const results = filteredResultsRef.current;

      switch (e.key) {
        case "Escape":
          onClose();
          break;
        case "ArrowRight":
          e.preventDefault();
          setSelectedIndex(i => Math.min(i + 1, results.length - 1));
          break;
        case "ArrowLeft":
          e.preventDefault();
          setSelectedIndex(i => Math.max(i - 1, 0));
          break;
        case "ArrowDown":
          e.preventDefault();
          setSelectedIndex(i => Math.min(i + cols, results.length - 1));
          break;
        case "ArrowUp":
          e.preventDefault();
          setSelectedIndex(i => Math.max(i - cols, 0));
          break;
        case "Enter":
          e.preventDefault();
          if (e.metaKey || e.ctrlKey) {
            handleSendToAI();
          } else {
            setSelectedIndex(i => {
              const r = filteredResultsRef.current[i];
              if (r) handleSelectResult(r);
              return i;
            });
          }
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    const captureEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", captureEscape, true);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("keydown", captureEscape, true);
    };
  }, [isOpen, selectedSpeaker, onClose, onNavigateToTimestamp, handleSelectResult, handleSendToAI, handleBackFromSpeaker]);

  // Scroll selected item into view (only on arrow-key navigation, not on new page load)
  const prevSelectedIndex = useRef(selectedIndex);
  useEffect(() => {
    if (prevSelectedIndex.current !== selectedIndex && gridRef.current && filteredResults.length > 0) {
      const selectedEl = gridRef.current.querySelector(`[data-index="${selectedIndex}"]`);
      selectedEl?.scrollIntoView({ block: "nearest" });
    }
    prevSelectedIndex.current = selectedIndex;
  }, [selectedIndex, filteredResults.length]);

  // Standalone: resize Tauri window based on content state.
  // DOM measurement fails because the small window viewport constrains layout.
  const hasAnyResults = searchResults.length > 0 || speakerResults.length > 0 || tagResults.length > 0 || uiEventResults.length > 0;
  const hasVisibleContent = hasAnyResults || (debouncedQuery && debouncedQuery.trim().length >= 2) || isSearching || isSearchingSpeakers || isSearchingTags || isSearchingUiEvents;
  // input ~52px; footer ~28px; results up to ~380px
  const standaloneTargetH = hasVisibleContent ? 580 : 80;

  useEffect(() => {
    if (!standalone || !isOpen) return;
    invoke("resize_search_window", { width: 680, height: standaloneTargetH }).catch(() => {});
  }, [standalone, isOpen, standaloneTargetH]);

  if (!isOpen) return null;

  const hasResults = searchResults.length > 0 || speakerResults.length > 0 || tagResults.length > 0 || uiEventResults.length > 0;
  const showEmpty = !isSearching && !isSearchingSpeakers && !isSearchingTags && !isSearchingUiEvents && debouncedQuery && debouncedQuery.trim().length >= 3 && !hasResults && !selectedSpeaker && !isTagSearch && !isPeopleSearch;
  const activeIndex = hoveredIndex ?? selectedIndex;

  const renderResults = () => (
    <>
      {/* === Speaker drill-down view === */}
      {selectedSpeaker ? (
        <div>
          {/* Back button + speaker name */}
          <button
            onClick={handleBackFromSpeaker}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <User className="w-3.5 h-3.5" />
            <span className="font-medium text-foreground">{selectedSpeaker.name}</span>
          </button>

          {isLoadingTranscriptions && (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="bg-muted animate-pulse rounded p-3 h-16" />
              ))}
            </div>
          )}

          {!isLoadingTranscriptions && speakerTranscriptions.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              no transcriptions found for {selectedSpeaker.name}
            </div>
          )}

          {/* App filter chips for speaker transcriptions */}
          {speakerAppCounts.length > 1 && (
            <div className="flex gap-1.5 mb-2 overflow-x-auto scrollbar-hide pb-0.5">
              <button
                onClick={() => { setSpeakerAppFilter(null); setSelectedTranscriptionIndex(0); }}
                className={cn(
                  "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                  !speakerAppFilter
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:border-foreground/40"
                )}
              >
                all ({speakerTranscriptions.length})
              </button>
              {speakerAppCounts.map(([app, count]) => (
                <button
                  key={app}
                  onClick={() => { setSpeakerAppFilter(speakerAppFilter === app ? null : app); setSelectedTranscriptionIndex(0); }}
                  className={cn(
                    "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                    speakerAppFilter === app
                      ? "bg-foreground text-background border-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/40"
                  )}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`http://localhost:11435/app-icon?name=${encodeURIComponent(app)}`}
                    className="w-4 h-4 rounded-sm object-contain"
                    alt=""
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                  {app} ({count})
                </button>
              ))}
            </div>
          )}

          {/* Time range filter chips for speaker transcriptions */}
          {speakerTimeRanges.length > 1 && (
            <div className="flex gap-1.5 mb-3 overflow-x-auto scrollbar-hide pb-0.5">
              <button
                onClick={() => { setSpeakerTimeFilter(null); setSelectedTranscriptionIndex(0); }}
                className={cn(
                  "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                  !speakerTimeFilter
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:border-foreground/40"
                )}
              >
                <Clock className="w-3 h-3" />
                all dates
              </button>
              {speakerTimeRanges.map((range) => (
                <button
                  key={range.dateKey}
                  onClick={() => { setSpeakerTimeFilter(speakerTimeFilter === range.dateKey ? null : range.dateKey); setSelectedTranscriptionIndex(0); }}
                  className={cn(
                    "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1 whitespace-nowrap shrink-0",
                    speakerTimeFilter === range.dateKey
                      ? "bg-foreground text-background border-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/40"
                  )}
                >
                  <Clock className="w-3 h-3" />
                  {range.label} ({range.count})
                </button>
              ))}
            </div>
          )}

          {filteredSpeakerTranscriptions.length > 0 && (
            <div className="grid grid-cols-3 gap-3">
              {filteredSpeakerTranscriptions.map((t, index) => {
                const frameInfo = transcriptionFrames.get(t.timestamp);
                const frameId = frameInfo?.frame_id;
                return (
                  <div
                    key={`${t.timestamp}-${index}`}
                    data-index={index}
                    onClick={() => {
                      if (t.timestamp) {
                        onNavigateToTimestamp(t.timestamp);
                        if (!embedded) onClose();
                      }
                    }}
                    className={cn(
                      "cursor-pointer rounded overflow-hidden border transition-all duration-150",
                      index === selectedTranscriptionIndex
                        ? "ring-2 ring-foreground border-foreground scale-[1.02] shadow-lg z-10"
                        : "border-border hover:border-foreground/50"
                    )}
                  >
                    {frameId ? (
                      <FrameThumbnail
                        frameId={frameId}
                        alt={t.transcription || t.speaker_name}
                      />
                    ) : (
                      <div className="aspect-video bg-muted flex items-center justify-center">
                        <Mic className="w-5 h-5 text-muted-foreground/40" />
                      </div>
                    )}
                    <div className="p-2 bg-card">
                      <p className="text-xs text-foreground line-clamp-2 leading-relaxed mb-1">
                        {t.transcription || "(empty)"}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {t.timestamp ? formatRelativeTime(t.timestamp) : "unknown"}
                        </span>
                        <span className="flex items-center gap-0.5">
                          {t.is_input ? <Mic className="w-2.5 h-2.5" /> : <Volume2 className="w-2.5 h-2.5" />}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Load more transcriptions indicator */}
          {speakerTranscriptions.length > 0 && (isLoadingMoreTranscriptions || hasMoreTranscriptions) && (
            <div className="flex justify-center py-4">
              {isLoadingMoreTranscriptions ? (
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              ) : (
                <span className="text-xs text-muted-foreground">scroll for more</span>
              )}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Empty state */}
          {showEmpty && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              no results for &quot;{debouncedQuery}&quot;
            </div>
          )}

          {/* Tag autocomplete pills */}
          {isTagSearch && allTags.length > 0 && (
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                <Tag className="w-3 h-3" />
                tags
              </p>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {allTags.map((t) => {
                  const tagQuery = query.slice(1).trim().toLowerCase();
                  const isActive = tagQuery === t;
                  return (
                    <button
                      key={t}
                      onClick={() => setQuery(`#${t}`)}
                      className={cn(
                        "inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-full border transition-colors cursor-pointer",
                        isActive
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-foreground/70 hover:bg-muted hover:border-foreground/30"
                      )}
                    >
                      <Hash className="w-2.5 h-2.5" />
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tag timeline entries — thumbnail grid */}
          {isTagSearch && tagResults.length > 0 && (
            <div className="grid grid-cols-3 gap-3">
              {tagResults.map((frame) => (
                <div
                  key={frame.frame_id}
                  onClick={() => {
                    const resultsJson = JSON.stringify(searchResults);
                    onNavigateToTimestamp(frame.timestamp, frame.frame_id, queryTokens, resultsJson, query);
                    if (!embedded) onClose();
                  }}
                  className="cursor-pointer rounded overflow-hidden border border-border hover:border-foreground/50 transition-all duration-150"
                >
                  <FrameThumbnail
                    frameId={frame.frame_id}
                    alt={frame.tag_names.join(", ")}
                  />
                  <div className="p-2 bg-card">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                      <Clock className="w-3 h-3" />
                      <span className="font-mono">
                        {formatRelativeTime(frame.timestamp)}
                      </span>
                    </div>
                    <p className="text-xs font-medium text-foreground truncate">
                      {frame.app_name || frame.tag_names[0]}
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {frame.tag_names.map((t) => (
                        <span
                          key={t}
                          className="px-1.5 py-0.5 text-[10px] rounded-full bg-foreground/8 text-foreground/60"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tag search loading */}
          {isTagSearch && isSearchingTags && tagResults.length === 0 && allTags.length === 0 && (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-muted animate-pulse rounded p-3 h-12" />
              ))}
            </div>
          )}

          {/* Tag search empty */}
          {isTagSearch && !isSearchingTags && tagResults.length === 0 && allTags.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              {query.slice(1).trim()
                ? <>no tags matching &quot;{query.slice(1).trim()}&quot;</>
                : "no tags found"}
            </div>
          )}

          {/* @ people search loading */}
          {isPeopleSearch && isSearchingSpeakers && speakerResults.length === 0 && (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-muted animate-pulse rounded p-3 h-10" />
              ))}
            </div>
          )}

          {/* @ people search empty */}
          {isPeopleSearch && !isSearchingSpeakers && speakerResults.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              {query.slice(1).trim()
                ? <>no people matching &quot;{query.slice(1).trim()}&quot;</>
                : "no speakers found"}
            </div>
          )}

          {/* Loading skeleton — filter chips + thumbnail grid */}
          {!isTagSearch && !isPeopleSearch && (isSearching || facetsLoading) && searchResults.length === 0 && uiEventResults.length === 0 && speakerResults.length === 0 && (
            <>
              {/* Skeleton filter chips */}
              <div className="flex gap-1.5 mb-2 overflow-hidden">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-6 bg-muted animate-pulse rounded-full shrink-0" style={{ width: `${60 + i * 12}px` }} />
                ))}
              </div>
              <div className="flex gap-1.5 mb-3 overflow-hidden">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-6 bg-muted animate-pulse rounded-full shrink-0" style={{ width: `${50 + i * 15}px` }} />
                ))}
              </div>
              {/* Skeleton thumbnail grid */}
              <div className="grid grid-cols-3 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-muted animate-pulse rounded overflow-hidden">
                    <div className="aspect-video" />
                    <div className="p-2 space-y-1">
                      <div className="h-3 bg-muted-foreground/20 rounded w-16" />
                      <div className="h-2 bg-muted-foreground/20 rounded w-24" />
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* People section */}
          {speakerResults.length > 0 && (
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                <User className="w-3 h-3" />
                people
              </p>
              <div className="flex gap-2 flex-wrap">
                {speakerResults.map((speaker) => (
                  <button
                    key={speaker.id}
                    onClick={() => {
                      setSelectedSpeaker(speaker);
                      setSelectedTranscriptionIndex(0);
                    }}
                    className="flex items-center gap-2 px-3 py-2 border border-border rounded-md
                      hover:bg-muted hover:border-foreground/30 transition-colors cursor-pointer"
                  >
                    <User className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-sm font-medium">{speaker.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Content type filter chips — shown when we have any results */}
          {(searchResults.length > 0 || uiEventResults.length > 0) && (
            <div className="flex gap-2 mb-3">
              {([
                { key: "all" as ContentFilter, label: "All", icon: null },
                { key: "screen" as ContentFilter, label: "Screen", icon: Monitor },
                { key: "input" as ContentFilter, label: "Keyboard & Clipboard", icon: Keyboard },
              ] as const).map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => { setContentFilter(key); setSelectedIndex(0); }}
                  className={cn(
                    "inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-full border transition-colors",
                    contentFilter === key
                      ? "bg-foreground text-background border-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/40"
                  )}
                >
                  {Icon && <Icon className="w-3 h-3" />}
                  {label}
                </button>
              ))}
            </div>
          )}

          {/* Screen results skeleton — keyword search still in flight but UI events already loaded */}
          {isSearching && searchResults.length === 0 && contentFilter !== "input" && uiEventResults.length > 0 && (
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                <Monitor className="w-3 h-3" />
                screen
              </p>
              <div className="grid grid-cols-3 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-muted animate-pulse rounded overflow-hidden">
                    <div className="aspect-video" />
                    <div className="p-2 space-y-1">
                      <div className="h-3 bg-muted-foreground/20 rounded w-16" />
                      <div className="h-2 bg-muted-foreground/20 rounded w-24" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* UI event results — shown above screen results so infinite scroll doesn't push them away */}
          {uiEventResults.length > 0 && contentFilter !== "screen" && (
            <div className={cn(contentFilter === "all" && "mb-4")}>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                <Keyboard className="w-3 h-3" />
                keyboard & clipboard
              </p>
              <div className="flex flex-col gap-2">
                {(contentFilter === "all" ? uiEventResults.slice(0, 5) : uiEventResults).map((evt) => (
                  <UiEventItem
                    key={evt.id}
                    evt={evt}
                    onNavigate={() => {
                      onNavigateToTimestamp(evt.timestamp);
                      if (!embedded) onClose();
                    }}
                  />
                ))}
              </div>
              {contentFilter === "all" && uiEventResults.length > 5 && (
                <button
                  onClick={() => setContentFilter("input")}
                  className="mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                >
                  show all {uiEventResults.length} results
                </button>
              )}
            </div>
          )}

          {/* Screen results grid */}
          {searchResults.length > 0 && contentFilter !== "input" && (
            <>
              {(speakerResults.length > 0 || (contentFilter === "all" && uiEventResults.length > 0)) && (
                <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                  <Monitor className="w-3 h-3" />
                  screen
                </p>
              )}

              {/* App filter chips */}
              {appCounts.length > 1 && (
                <div className="flex gap-1.5 mb-2 overflow-x-auto scrollbar-hide pb-0.5">
                  <button
                    onClick={() => { setAppFilter(null); setSelectedIndex(0); }}
                    className={cn(
                      "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                      !appFilter
                        ? "bg-foreground text-background border-foreground"
                        : "border-border text-muted-foreground hover:border-foreground/40"
                    )}
                  >
                    all ({searchResults.length})
                  </button>
                  {appCounts.map(([app, count]) => (
                    <button
                      key={app}
                      onClick={() => { const newApp = appFilter === app ? null : app; setAppFilter(newApp); if (newApp) setDomainFilter(null); setSelectedIndex(0); }}
                      className={cn(
                        "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                        appFilter === app
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:border-foreground/40"
                      )}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={`http://localhost:11435/app-icon?name=${encodeURIComponent(app)}`}
                        className="w-4 h-4 rounded-sm object-contain"
                        alt=""
                        onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                      />
                      {app} ({count})
                    </button>
                  ))}
                </div>
              )}

              {/* Domain filter chips — hide when a non-browser app is selected
                  (non-browser apps don't have URLs so domain chips are irrelevant) */}
              {domainCounts.length > 1 && (!appFilter || filteredResults.some(r => r.url)) && (
                <div className="flex gap-1.5 mb-2 overflow-x-auto scrollbar-hide pb-0.5">
                  <button
                    onClick={() => { setDomainFilter(null); setSelectedIndex(0); }}
                    className={cn(
                      "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                      !domainFilter
                        ? "bg-foreground text-background border-foreground"
                        : "border-border text-muted-foreground hover:border-foreground/40"
                    )}
                  >
                    all sites
                  </button>
                  {domainCounts.map(([domain, count]) => (
                    <button
                      key={domain}
                      onClick={() => { setDomainFilter(domainFilter === domain ? null : domain); setSelectedIndex(0); }}
                      className={cn(
                        "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                        domainFilter === domain
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:border-foreground/40"
                      )}
                    >
                      {domain} ({count})
                    </button>
                  ))}
                </div>
              )}

              {/* Time range filter chips */}
              {timeRanges.length > 1 && (
                <div className="flex gap-1.5 mb-3 overflow-x-auto scrollbar-hide pb-0.5">
                  <button
                    onClick={() => {
                      setTimeFilter(null);
                      setSelectedIndex(0);
                      setOcrOffset(0);
                      setHasMoreOcr(true);
                      searchKeywords(debouncedQuery, { limit: OCR_PAGE_SIZE, offset: 0 });
                    }}
                    className={cn(
                      "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0",
                      !timeFilter
                        ? "bg-foreground text-background border-foreground"
                        : "border-border text-muted-foreground hover:border-foreground/40"
                    )}
                  >
                    <Clock className="w-3 h-3" />
                    all dates
                  </button>
                  {timeRanges.map((range) => (
                    <button
                      key={range.dateKey}
                      onClick={() => {
                        const newFilter = timeFilter === range.dateKey ? null : range.dateKey;
                        setTimeFilter(newFilter);
                        setSelectedIndex(0);
                        // Re-query backend with date range for proper pagination
                        setOcrOffset(0);
                        setHasMoreOcr(true);
                        if (newFilter) {
                          const start = new Date(newFilter + "T00:00:00");
                          const end = new Date(newFilter + "T23:59:59.999");
                          searchKeywords(debouncedQuery, { limit: OCR_PAGE_SIZE, offset: 0, start_time: start, end_time: end });
                        } else {
                          searchKeywords(debouncedQuery, { limit: OCR_PAGE_SIZE, offset: 0 });
                        }
                      }}
                      className={cn(
                        "px-2.5 py-1 text-[11px] rounded-full border transition-colors flex items-center gap-1 whitespace-nowrap shrink-0",
                        timeFilter === range.dateKey
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:border-foreground/40"
                      )}
                    >
                      <Clock className="w-3 h-3" />
                      {range.label} ({range.count})
                    </button>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                {filteredResults.map((result, index) => {
                  const isActive = index === activeIndex;
                  const group = filteredGroups[index];
                  const groupSize = group?.group_size ?? 1;

                  return (
                    <div
                      key={result.frame_id}
                      data-index={index}
                      onClick={() => handleSelectResult(result)}
                      onMouseEnter={() => setHoveredIndex(index)}
                      onMouseLeave={() => setHoveredIndex(null)}
                      className={cn(
                        "cursor-pointer rounded overflow-hidden border transition-all duration-150",
                        isActive
                          ? "ring-2 ring-foreground border-foreground scale-[1.02] shadow-lg z-10"
                          : "border-border hover:border-foreground/50"
                      )}
                    >
                      <div className="relative">
                        <FrameThumbnail
                          frameId={result.frame_id}
                          alt={`${result.app_name} - ${result.window_name}`}
                        />
                        {queryTokens.length > 0 && (
                          <ThumbnailHighlightOverlay
                            frameId={result.frame_id}
                            highlightTerms={queryTokens}
                          />
                        )}
                        {groupSize > 1 && (
                          <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 text-[10px] font-medium bg-black/70 text-white rounded">
                            {groupSize} frames
                          </span>
                        )}
                      </div>
                      <div className="p-2 bg-card">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1">
                          <Clock className="w-3 h-3" />
                          <span className="font-mono">
                            {groupSize > 1 && group
                              ? `${formatRelativeTime(group.start_time)} – ${formatRelativeTime(group.end_time)}`
                              : formatRelativeTime(result.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs font-medium text-foreground truncate">
                          {result.app_name}
                        </p>
                        {isActive && (
                          <div className="mt-1 pt-1 border-t border-border space-y-1">
                            <p className="text-xs text-muted-foreground line-clamp-2">
                              {result.window_name}
                            </p>
                            {result.url && (
                              <p className="text-xs text-muted-foreground/70 truncate">
                                {result.url}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Load more indicator */}
              {(isLoadingMore || (hasMoreOcr && filteredResults.length > 0)) && (
                <div className="flex justify-center py-4">
                  {isLoadingMore ? (
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  ) : (
                    <span className="text-xs text-muted-foreground">scroll for more</span>
                  )}
                </div>
              )}
            </>
          )}


          {/* Suggestions when no query */}
          {!debouncedQuery && !isSearching && (
            <div className="py-8 px-2">
              {suggestions.length > 0 ? (
                <>
                  <p className="text-xs text-muted-foreground mb-3 text-center">
                    from your recent activity
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {suggestions.map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => setQuery(suggestion)}
                        className="px-3 py-1.5 text-sm border border-border rounded-md
                          hover:bg-muted hover:border-foreground/30 transition-colors
                          text-foreground/80 hover:text-foreground cursor-pointer"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </>
              ) : suggestionsLoading ? (
                <div className="text-center text-sm text-muted-foreground">
                  loading suggestions...
                </div>
              ) : (
                <div className="text-center text-sm text-muted-foreground">
                  type to search your screen history
                </div>
              )}
            </div>
          )}
        </>
      )}
    </>
  );

  if (standalone || embedded) {
    const hasContent = hasResults || (debouncedQuery && debouncedQuery.trim().length >= 2) || isSearching || isSearchingSpeakers || isSearchingTags || isSearchingUiEvents;
    return (
      <div className={cn(
        "flex flex-col bg-card/95 backdrop-blur-xl",
        standalone ? "rounded-xl border border-border/50 shadow-2xl overflow-hidden" : "h-full",
      )}>
        {/* Search Input — Raycast-style large input */}
        <div className={cn(
          "flex items-center gap-3 px-5 border-b border-border/50",
          standalone ? "py-3.5" : "py-3 px-4",
        )}
        data-tauri-drag-region={standalone ? true : undefined}
        >
          <Search className="w-4.5 h-4.5 text-muted-foreground flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              if (selectedSpeaker) {
                setSelectedSpeaker(null);
                setSpeakerTranscriptions([]);
                setSelectedTranscriptionIndex(0);
                setTranscriptionOffset(0);
                setHasMoreTranscriptions(true);
              }
            }}
            placeholder="search your memory... (# tags, @ people)"
            className={cn(
              "flex-1 bg-transparent text-foreground placeholder:text-muted-foreground/60 outline-none",
              standalone ? "text-base" : "text-sm",
            )}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
          />
          {(isSearching || isSearchingTags) && <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />}
          {query && (
            <button
              onClick={() => setQuery("")}
              className="p-1 hover:bg-muted rounded"
            >
              <X className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          )}
        </div>

        {/* Results area — only shown when there's content */}
        {hasContent && (
          <div
            ref={gridRef}
            className={cn(
              "flex-1 min-h-0 overflow-y-auto overscroll-contain touch-pan-y",
              standalone ? "p-3 max-h-[500px] scrollbar-hide" : "p-4",
            )}
            onWheel={(e) => {
              e.stopPropagation();
              const target = e.currentTarget;
              const isAtTop = target.scrollTop === 0 && e.deltaY < 0;
              const isAtBottom = target.scrollTop + target.clientHeight >= target.scrollHeight && e.deltaY > 0;
              if (isAtTop || isAtBottom) e.preventDefault();
            }}
            onTouchMove={(e) => e.stopPropagation()}
            onScroll={handleScroll}
          >
            {renderResults()}
          </div>
        )}

        {/* Footer — compact keyboard hints */}
        <div className={cn(
          "px-4 py-1.5 border-t border-border/50 flex items-center justify-between text-[10px] text-muted-foreground/70 font-mono",
          standalone ? "bg-muted/20" : "bg-muted/30 py-2",
        )}>
          <div className="flex items-center gap-4">
            {selectedSpeaker ? (
              <>
                <span>↑↓ navigate</span>
                <span>⏎ go to timeline</span>
                <span>esc back</span>
              </>
            ) : (
              <>
                <span>←→↑↓ navigate</span>
                <span>⏎ go to timeline</span>
                <span className="flex items-center gap-1">
                  <MessageSquare className="w-2.5 h-2.5" />
                  ⌘⏎ ask AI
                </span>
              </>
            )}
          </div>
          <span>esc close</span>
        </div>
      </div>
    );
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] isolate"
      onWheel={(e) => e.stopPropagation()}
      onTouchMove={(e) => e.stopPropagation()}
    >
      {/* Backdrop - captures all pointer events to prevent interaction with timeline */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        onWheel={(e) => e.stopPropagation()}
        onTouchMove={(e) => e.stopPropagation()}
      />

      {/* Modal */}
      <div className="relative w-full max-w-4xl mx-4 bg-card border border-border shadow-2xl overflow-hidden rounded-lg isolate">
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
          <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              // Exit speaker drill-down when user edits search query
              if (selectedSpeaker) {
                setSelectedSpeaker(null);
                setSpeakerTranscriptions([]);
                setSelectedTranscriptionIndex(0);
                setTranscriptionOffset(0);
                setHasMoreTranscriptions(true);
              }
            }}
            placeholder="Search your memory... (# tags, @ people)"
            className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground text-sm outline-none"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
          />
          {(isSearching || isSearchingTags) && <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />}
          {query && (
            <button
              onClick={() => setQuery("")}
              className="p-1 hover:bg-muted rounded"
            >
              <X className="w-3 h-3 text-muted-foreground" />
            </button>
          )}
        </div>

        {/* Results area - isolate scroll to prevent timeline from scrolling */}
        <div
          ref={gridRef}
          className="max-h-[60vh] overflow-y-auto p-4 overscroll-contain touch-pan-y"
          onWheel={(e) => {
            e.stopPropagation();
            const target = e.currentTarget;
            const isAtTop = target.scrollTop === 0 && e.deltaY < 0;
            const isAtBottom = target.scrollTop + target.clientHeight >= target.scrollHeight && e.deltaY > 0;
            if (isAtTop || isAtBottom) e.preventDefault();
          }}
          onTouchMove={(e) => e.stopPropagation()}
          onScroll={handleScroll}
        >
          {renderResults()}
        </div>

        {/* Footer with keyboard hints */}
        <div className="px-4 py-2 border-t border-border bg-muted/30 flex items-center justify-between text-[10px] text-muted-foreground font-mono">
          <div className="flex items-center gap-4">
            {selectedSpeaker ? (
              <>
                <span>↑↓ navigate</span>
                <span>⏎ go to timeline</span>
                <span>esc back</span>
              </>
            ) : (
              <>
                <span>←→↑↓ navigate</span>
                <span>⏎ go to timeline</span>
                <span className="flex items-center gap-1">
                  <MessageSquare className="w-3 h-3" />
                  ⌘⏎ ask AI
                </span>
              </>
            )}
          </div>
          <span>esc {selectedSpeaker ? "back" : "close"}</span>
        </div>
      </div>
    </div>
  );
}
